import kotlin.system.exitProcess
import java.util.Scanner


open class robot {
    open fun Alaram() {
        println("Hello this is robot SID")
        println("Your alaram is set to ring at 7 am")
        val reader = Scanner(System.`in`)
        println("Press 1 to go to menu : ")
        var integer: Int = reader.nextInt()
        if (integer == 1) {
            menu()
        } else {
            exitProcess(0)
        }


    }

    open fun MakeCoffee() {
        var option = 0
do {
    println(" How do you like your coffee (Black/With Milk)" + "\n 1)For Black press 1" + "\n 2)For Milk press 2"+"\n3)Menu")

    println("Enter : ")
    var reader = Scanner(System.`in`)
    var option: Int = reader.nextInt()

    when (option) {
        1 -> println("Making black Coffee")
        2 -> println("Making coffe with Milk")
        3 -> menu()
    }
    if (option >= 3 || option < 0) {
        println("Enter either 1 or 2")
    }
}
    while (option!=0)
    }

    open fun HeatWater(){
        var opt = 0.0
        do {
            println("\t\t\tHeating water...")
            println("Enter Temperature in Decimals ")
            println("Enter Temperature for Heating in Celsius : ")
            var reader = Scanner(System.`in`)
            var opt: Double = reader.nextDouble()
            println("Heating water at $opt Degree Celsius temperature")
            menu()
        }
            while(opt!=0.0)


    }

open fun PackBag() {
    open class subjects {
        var sub1: String = "English"
        var sub2: String = "Maths"
        var sub3: String = "Biology"
        fun day1() {
            println("Timetable for day1 is : $sub1 , $sub2")
        }

        fun day2() {
            println("Timetable for day1 is : $sub2 , $sub3")
        }

        fun day3() {
            println("Timetable for day1 is : $sub2 , $sub1")
        }

    }
    var days1 = subjects()
    days1.day1()
    var days2 = subjects()
    days2.day2()
    var days3 = subjects()
    days3.day3()

}



    open fun BreakLun(){
        var opts = 0
      do {
          var brk = listOf("carrots", "potatoes", "tomatoes")
          println("Which food items do you like $brk : ")
          println("Type 1,2,3" + "\npress 4 to select randomly from list")
         var reader = Scanner(System.`in`)
          var opts: Int = reader.nextInt()

          when(opts){
              1 -> println("Making carrots for breakfast ")
              2 -> println("Making potatoes for breakfast")
              3 -> println("Making Tomatoes for breakfast")
              4 -> println(brk.random())
          }
         menu()
      }
          while(opts!=0)
    }

    fun IronClothes(){
        var opt1 = 0

        do {
            var clothes = listOf("Formals","Tshirts","Shorts")
            println("What do you want to wear $clothes : ")
            println("Type 1,2,3")
            var reader = Scanner(System.`in`)
            var opt1: Int = reader.nextInt()
            when(opt1){
                1 -> println("Ironing formals for you.. ")
                2 -> println("Ironing Tshirts for you..")
                3 -> println("Ironing Shorts for you..")
            }
            menu()
        }
            while(opt1!=0)

    }


        open fun menu() {
            var choice = 1
            do {

                println(
                    " \t\t\tROBOT SIDD\t\t\t\n" +
                            " 1)Alaram\n 2)Coffee Details\n 3)Heat the water\n 4)Pack bag\n 5)Cook breakfast and lunch\n 6)Iron clothes\n 7)Exit\n"
                )
                println("Enter your choice : ")
                var reader = Scanner(System.`in`)
                var choice: Int = reader.nextInt()
                when (choice) {
                    1 -> Alaram()
                    2 -> MakeCoffee()
                    3 -> HeatWater()
                    4 -> PackBag()
                    5 -> BreakLun()
                    6 -> IronClothes()
                    7 -> exitProcess(5)
                }
            } while (choice != 0)
        }


    }

fun main() {
var rob = robot()
    rob.menu()
}